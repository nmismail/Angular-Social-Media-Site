export class Register {
    constructor(firstname: String, lastname: String, email: String,
    dob: String, password: String, genreOne: String, genreTwo: String,
    genreThree: String) {
    }
}
