export interface User {userId: number; firstname: String; lastname: String; email:
String; dob: String; password: String; genreOne: String; genreTwo: String; genreThree: String;
picture: String; bio: String; }
